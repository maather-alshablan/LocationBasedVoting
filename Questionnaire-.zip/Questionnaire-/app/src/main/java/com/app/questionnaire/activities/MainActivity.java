package com.app.questionnaire.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.app.questionnaire.Helper.PreferenceHelper;
import com.app.questionnaire.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private PreferenceHelper preferenceHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preferenceHelper = new PreferenceHelper(this);

        ImageView image_logout = findViewById(R.id.image_logout);
        LinearLayout line_add = findViewById(R.id.line_add);
        LinearLayout line_all = findViewById(R.id.line_all);
        LinearLayout add_location = findViewById(R.id.add_location);
        SwitchCompat switch_mute = findViewById(R.id.switch_mute);

        image_logout.setOnClickListener(this);
        line_add.setOnClickListener(this);
        line_all.setOnClickListener(this);
        add_location.setOnClickListener(this);

        switch_mute.setOnCheckedChangeListener((compoundButton, b) -> {
            preferenceHelper.setIsMute(b);
        });


        if (preferenceHelper.IS_Mute_SET()) {
            switch_mute.setChecked(true);
        } else {
            switch_mute.setChecked(false);
        }

    }

    @Override
    public void onClick(View view) {

        if (view.getId() == R.id.image_logout) {
            // sharedPreferences حذف القيم المخزنة في ال
            preferenceHelper.setUserId(-1);
            preferenceHelper.setPassword("");
            preferenceHelper.setUsername("");
            startActivity(new Intent(MainActivity.this, SignInActivity.class));
            finish();
        } else if (view.getId() == R.id.line_add) {
            startActivity(new Intent(MainActivity.this, AddQuestionnaireActivity.class));
        } else if (view.getId() == R.id.add_location) {
            startActivity(new Intent(MainActivity.this, AddLocationActivity.class));
        } else if (view.getId() == R.id.line_all) {
            startActivity(new Intent(MainActivity.this, AllQuestionnaireActivity.class));
        }

    }
}
