package com.app.questionnaire.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.app.questionnaire.Modle.Colleges;
import com.app.questionnaire.R;
import com.app.questionnaire.interfaces.OnItemClickListener;
import java.util.List;


public class ListPopupCollegesAdapter extends BaseAdapter {
    private Activity mActivity;
    private List<Colleges> cities;
    private LayoutInflater layoutInflater;


    private OnItemClickListener mOnItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        mOnItemClickListener = onItemClickListener;
    }

    public ListPopupCollegesAdapter(Activity activity, List<Colleges> cities) {
        this.mActivity = activity;
        this.cities = cities;
        layoutInflater = mActivity.getLayoutInflater();
    }



    @Override
    public int getCount() {
        return cities.size();
    }

    @Override
    public Object getItem(int i) {
        return cities.get(i);
    }


    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView( int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = layoutInflater.inflate(R.layout.item_colleges, null);
            holder.tv_college = convertView.findViewById(R.id.tv_college);
            holder.line_popup = convertView.findViewById(R.id.line_popup);


            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Colleges data = cities.get(position);

        holder.tv_college.setText(data.getName());

        holder.line_popup.setOnClickListener(v -> {
            mOnItemClickListener.onClick(data, v, position);
        });


        return convertView;
    }

    public class ViewHolder {
        private TextView tv_college;
        private LinearLayout line_popup ;

    }


}