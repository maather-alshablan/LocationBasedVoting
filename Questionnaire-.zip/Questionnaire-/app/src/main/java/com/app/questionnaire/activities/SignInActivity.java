package com.app.questionnaire.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.app.questionnaire.DB.DataBaseS;
import com.app.questionnaire.DBDao.DbDao;
import com.app.questionnaire.Helper.PreferenceHelper;
import com.app.questionnaire.R;

public class SignInActivity extends AppCompatActivity implements View.OnClickListener {

    public static int staticUserId = -1;
    private EditText ed_user_login, ed_pass_login;
    private TextView tv_Sign_Up;
    private Button btn_sign_in;
    private CheckBox checked_remember;
    private String user_name, pass;
    private DataBaseS database;
    private PreferenceHelper preferences;

    // يتم من خلاها فحص ال edit اذا فاضي او لا
    public static boolean ValidationEmptyInput(EditText text) {
        if (TextUtils.isEmpty(text.getText().toString())) {
            return false;
        }
        return true;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        findViews();

    }

    // عشان اقدر اتحم بالعناصر الموجودة ف ال Activity و افعل الضغطة مثلا على الزر
    private void findViews() {
        database = DataBaseS.getInstance(this);
        preferences = new PreferenceHelper(this);


        tv_Sign_Up = findViewById(R.id.tv_Sign_Up);
        btn_sign_in = findViewById(R.id.btn_sign_in);
        ed_user_login = findViewById(R.id.ed_user_login);
        ed_pass_login = findViewById(R.id.ed_pass_login);
        checked_remember = findViewById(R.id.checked_remember);

        tv_Sign_Up.setOnClickListener(this);
        btn_sign_in.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.tv_Sign_Up) {
            startActivity(new Intent(SignInActivity.this, SignUpActivity.class));
        } else if (view.getId() == R.id.btn_sign_in) {
            if (validation()) {
                user_name = ed_user_login.getText().toString();
                pass = ed_pass_login.getText().toString();
                //create an instance from our Dao
                DbDao dao = database.getDao();
                //  يتم ارسال القيم الي الداتا بيس و يتم ارجاع id_user اذا = 0 بيكون اليوزر مش مسجل
                int id_user = dao.getUser(user_name, pass);

                Log.e("id_user", id_user + "");

                if (id_user != 0) {
                    staticUserId = id_user;
                    if (checked_remember.isChecked()) {
                        // if the user checked rememberMe checkbox ,then save his data
                        writeOnPreference_id(id_user);
                    }
                    startActivity(new Intent(this, MainActivity.class));
                    finish();

                } else {
                    Toast.makeText(this, "Please Register a new User is not present", Toast.LENGTH_SHORT).show();
                }
            }
        }

    }

    // هذه الدالة تقوم بقحص جميع المدخلات اذا موجودة او لا
    private boolean validation() {
        if (!ValidationEmptyInput(ed_user_login)) {
            Toast.makeText(this, "User Name is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else if (!ValidationEmptyInput(ed_pass_login)) {
            Toast.makeText(this, "Password is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else {
            return true;

        }
    }

    // تحزين id_user داخل ال sharedPreferences
    private void writeOnPreference_id(int id_user) {
        preferences.setUserId(id_user);

    }


}