package com.app.questionnaire.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.app.questionnaire.DB.DataBaseS;
import com.app.questionnaire.Modle.User;
import com.app.questionnaire.R;
import com.app.questionnaire.async.AsyncTasks;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int MY_CAMERA_REQUEST_CODE = 100;
    private static int CAMERA_PIC_REQUEST = 0;
    private EditText ed_user_name, ed_mobile_number, ed_pass, ed_confirm_pass;
    private ImageView image_user;
    private Button btn_sign_up;
    private TextView tv_Sign_in;
    private DataBaseS database;
    private String user_name, pass, cpass, mobile_number;
    // يتم من خلاها فحص ال edit اذا فاضي او لا

    public static boolean ValidationEmptyInput(EditText text) {
        if (TextUtils.isEmpty(text.getText().toString())) {
            return false;
        }
        return true;

    }


    // عشان اقدر اتحم بالعناصر الموجودة ف ال Activity و افعل الضغطة مثلا على الزر

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        findView();


    }

    private void findView() {
        database = DataBaseS.getInstance(this);

        btn_sign_up = findViewById(R.id.btn_sign_up);
        ed_user_name = findViewById(R.id.ed_user_name);
        ed_mobile_number = findViewById(R.id.ed_mobile_number);
        ed_pass = findViewById(R.id.ed_pass);
        ed_confirm_pass = findViewById(R.id.ed_confirm_pass);
        tv_Sign_in = findViewById(R.id.tv_Sign_in);
        image_user = findViewById(R.id.image_user);

        tv_Sign_in.setOnClickListener(this);
        btn_sign_up.setOnClickListener(this);
        image_user.setOnClickListener(this);

    }


    // هذه الدالة تقوم بقحص جميع المدخلات اذا موجودة او لا

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_Sign_in:
                finish();
                break;

            case R.id.btn_sign_up:
                if (validation()) {
                    user_name = ed_user_name.getText().toString();
                    pass = ed_pass.getText().toString();
                    mobile_number = ed_mobile_number.getText().toString();
                    cpass = ed_confirm_pass.getText().toString();

                    AsyncTasks asyncTasks = new AsyncTasks(getApplication());

                    // يتم الفحص اذا كلمة المرور تساوي تأكيد كلمة المرور
                    if (!pass.equals(cpass)) {
                        Toast.makeText(this, "Please Make Sure To Confirm The Password", Toast.LENGTH_SHORT).show();
                    } else {
                        // اضافة اليورز الي الداتا بيس
                        asyncTasks.addUser(new User(user_name, mobile_number, pass));
                        finish();
                        Toast.makeText(SignUpActivity.this, "User Added Successfully ", Toast.LENGTH_LONG).show();
                    }


                }

                break;

            case R.id.image_user:
                // يتم طلب البرمشن للدخول الي الكاميرا
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_REQUEST_CODE);
                        }
                    } else {
                        // الانتقال الي الكاميرا
                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST);

                    }
                }
                break;
        }
    }

    private boolean validation() {
        if (!ValidationEmptyInput(ed_user_name)) {
            Toast.makeText(this, "User Name is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else if (!ValidationEmptyInput(ed_mobile_number)) {
            Toast.makeText(this, "Mobile Number is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else if (!ValidationEmptyInput(ed_pass)) {
            Toast.makeText(this, "Password is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else if (!ValidationEmptyInput(ed_confirm_pass)) {
            Toast.makeText(this, "Confirm Password is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else {
            return true;

        }
    }

    // اليبانات المرجعة من الكاميرا و عرضها في صورة
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_PIC_REQUEST) {
            Bitmap image = (Bitmap) data.getExtras().get("data");
            image_user.setImageBitmap(image);
        }
    }


    // طلب البرمشن اذا عمل رفض ل برمشن الكاميرا
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "camera permission granted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

}
