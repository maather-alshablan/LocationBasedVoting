package com.app.questionnaire.activities;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.TaskStackBuilder;

import com.app.questionnaire.Adapter.ListPopupCollegesAdapter;
import com.app.questionnaire.BroadCast.DeadlineReceiver;
import com.app.questionnaire.BroadCast.NotificationReceiver;
import com.app.questionnaire.DB.DataBaseS;
import com.app.questionnaire.Helper.PreferenceHelper;
import com.app.questionnaire.Modle.Colleges;
import com.app.questionnaire.Modle.Questionnaire;
import com.app.questionnaire.R;
import com.app.questionnaire.async.AsyncTasks;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class AddQuestionnaireActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int REQUEST_CODE = 3943030;
    String description = "The questionnaire was created successfully , tap to show";
    private EditText ed_question, ed_first, ed_second,ed_third;
    private TextView tv_college, tv_choose_date, tv_choose_time;
    private List<Colleges> collegesArrayList;
    private DataBaseS database;
    private ListPopupWindow listPopupWindow;
    private double lat = 0.0;
    private double lng = 0.0;
    private PreferenceHelper preferences;
    private long date, time;
    private long notificationDelay = 24 * 60 * 60 * 1000; // notification will be after 24 hour
    private String question;
    private String first;
    private String second;
    private String third;
    private String dateStr;
    private String timeStr;
    private int currentIndex;
    private Notification.Builder builder;
    private NotificationManagerCompat notificationManager;
    private String channelId;

    // يتم من خلاها فحص ال edit اذا فاضي او لا
    public static boolean ValidationEmptyInput(EditText text) {
        if (TextUtils.isEmpty(text.getText().toString())) {
            return false;
        }
        return true;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_questionnaire);
        preferences = new PreferenceHelper(this);
        //here we get the id of the last added questionnaire
        currentIndex = preferences.getLastId();
        //now set the last added questionnaire id
        preferences.setLastId(currentIndex + 1);
        findView();

    }

    private void findView() {
        //set back arrow event handler
        ImageView back = findViewById(R.id.image_back);
        back.setOnClickListener(v -> onBackPressed());
        collegesArrayList = new ArrayList<>();
        database = DataBaseS.getInstance(this);

        tv_college = findViewById(R.id.tv_college);
        Button btn_add = findViewById(R.id.btn_add);
        ed_question = findViewById(R.id.ed_question);
        ed_first = findViewById(R.id.ed_first);
        ed_second = findViewById(R.id.ed_second);
        ed_third = findViewById(R.id.ed_third);
        tv_choose_date = findViewById(R.id.tv_choose_date);
        tv_choose_time = findViewById(R.id.tv_choose_time);

        btn_add.setOnClickListener(this);
        tv_college.setOnClickListener(this);
        tv_choose_date.setOnClickListener(this);
        tv_choose_time.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn_add) {
            if (validation()) {
                question = ed_question.getText().toString();
                first = ed_first.getText().toString();
                second = ed_second.getText().toString();
                third = ed_third.getText().toString();
                dateStr = tv_choose_date.getText().toString();
                timeStr = tv_choose_time.getText().toString();
                AsyncTasks asyncTasks = new AsyncTasks(this);
                asyncTasks.addQuestionnaire(new Questionnaire(currentIndex, question, first, second, third, lat, lng, dateStr, timeStr, true));

                try {
                    setupDeadlineReceiver();
                    setupNotification();
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                finish();
            }
        }

        if (view.getId() == R.id.tv_college)
            showListPopup(tv_college);

        if (view.getId() == R.id.tv_choose_date) {
            showCalendarDialog();

        }

        if (view.getId() == R.id.tv_choose_time) {
            Calendar timeCalendar = Calendar.getInstance();

            TimePickerDialog timePickerDialog = new TimePickerDialog(AddQuestionnaireActivity.this, R.style.datepicker, (timePicker, i, i1) -> {

                //create a calendar instance to get the time as long value that can be stored
                timeCalendar.set(0, 0, 0, i, i1);
                timeCalendar.set(Calendar.MILLISECOND, 0);
                time = timeCalendar.getTimeInMillis();
                tv_choose_time.setText(longToTimeString(time));

            }, timeCalendar.get(Calendar.HOUR), timeCalendar.get(Calendar.MINUTE), true);
            timePickerDialog.show();
        }
    }

    private void setupNotification() throws ParseException {
        Intent receiverIntent = new Intent(this, NotificationReceiver.class);
        receiverIntent.putExtra("id", currentIndex);
        receiverIntent.putExtra("title", question);
        receiverIntent.putExtra("date", dateStr);
        receiverIntent.putExtra("time", timeStr);
        receiverIntent.putExtra("isActive", true);
        receiverIntent.putExtra("First_team", first);
        receiverIntent.putExtra("Second_team", second);
        receiverIntent.putExtra("third_team", third);
        receiverIntent.putExtra("lat", lat);
        receiverIntent.putExtra("lng", lng);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, currentIndex, receiverIntent, 0);
        //building calendar object that we gonna use with pending intent will be sent to receiver
        Calendar calendar = Calendar.getInstance();
        //there are two notification , the first one is sent immediately
        sendImmediateNotification();
        //the second notification is sent after 24 hours of questionnaire deadline
        // first we have to add the delay of notification to the deadline date
        long delayedDate = date + notificationDelay;
        Date dayObj = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(formatToDisplayDate(delayedDate));
        Date timeObj = new SimpleDateFormat("HH:mm", Locale.US).parse(longToTimeString(time));
        calendar.setTime(timeObj);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        calendar.setTime(dayObj);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, min);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        AlarmManager alarmManager;
        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    }

    private void setupDeadlineReceiver() throws ParseException {
        Intent deadlineIntent = new Intent(this, DeadlineReceiver.class);
        deadlineIntent.putExtra("id", currentIndex);
        deadlineIntent.putExtra("title", question);
        deadlineIntent.putExtra("date", dateStr);
        deadlineIntent.putExtra("time", timeStr);
        deadlineIntent.putExtra("isActive", true);
        deadlineIntent.putExtra("First_team", first);
        deadlineIntent.putExtra("Second_team", second);
        deadlineIntent.putExtra("third_team", third);
        deadlineIntent.putExtra("lat", lat);
        deadlineIntent.putExtra("lng", lng);

        PendingIntent deadlinePending = PendingIntent.getBroadcast(this, currentIndex, deadlineIntent, 0);
        //building calendar object that we gonna use with pending intent will be sent to receiver
        Calendar calendar = Calendar.getInstance();
        Date dayObj = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(formatToDisplayDate(date));
        Date timeObj = new SimpleDateFormat("HH:mm", Locale.US).parse(longToTimeString(time));
        calendar.setTime(timeObj);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        calendar.setTime(dayObj);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, min);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), deadlinePending);
    }

    private void showListPopup(View anchorView) {
        listPopupWindow = new ListPopupWindow(this);
        listPopupWindow.setAnchorView(anchorView);
        // لعرض الكليات من الداتا بيس
        collegesArrayList = database.getDao().getAllColleges();

        ListPopupCollegesAdapter listPopupCollegesAdapter = new ListPopupCollegesAdapter(AddQuestionnaireActivity.this, collegesArrayList);
        listPopupWindow.setAdapter(listPopupCollegesAdapter);
        listPopupWindow.setWidth(ListPopupWindow.WRAP_CONTENT);
        listPopupWindow.setHeight(ListPopupWindow.WRAP_CONTENT);

        listPopupCollegesAdapter.setOnItemClickListener((parent, view, position) -> {
            listPopupWindow.dismiss();
            Colleges data = collegesArrayList.get(position);

            tv_college.setText(data.getName());

            lat = data.getLat();
            lng = data.getLng();

        });

        listPopupWindow.show();
    }

    // ديلوق اختيار التاريخ
    private void showCalendarDialog() {
        final Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int mDay = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(Objects.requireNonNull(AddQuestionnaireActivity.this), R.style.datepicker,
                (view, year, monthOfYear, dayOfMonth) -> {

                    //create a calendar instance to get the date as long value that can be stored
                    Calendar dateCalendar = Calendar.getInstance();
                    dateCalendar.set(year, monthOfYear, dayOfMonth, 0, 0, 0);
                    dateCalendar.set(Calendar.MILLISECOND, 0);
                    date = dateCalendar.getTimeInMillis();
                    tv_choose_date.setText(formatToDisplayDate(date));


                }, mYear, mMonth, mDay);
        datePickerDialog.setTitle("");
        datePickerDialog.getDatePicker().setMinDate((System.currentTimeMillis() + 0 * 24 * 60 * 60 * 1000));
        datePickerDialog.show();
    }

    // هذه الدالة تقوم بقحص جميع المدخلات اذا موجودة او لا
    private boolean validation() {
        if (!ValidationEmptyInput(ed_question)) {
            Toast.makeText(this, "Question is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else if (!ValidationEmptyInput(ed_first)) {
            Toast.makeText(this, "First Team is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else if (!ValidationEmptyInput(ed_second)) {
            Toast.makeText(this, "The Second Team is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else if (!ValidationEmptyInput(ed_third)) {
            Toast.makeText(this, "The Third Team is Empty", Toast.LENGTH_LONG).show();

            return false;

        } else if (lat == 0.0 || lng == 0.0) {
            Toast.makeText(this, "Please Choose a College", Toast.LENGTH_LONG).show();
            return false;

        } else if (tv_choose_date.getText().toString().equals("Choose a Date")) {
            Toast.makeText(this, "Please Choose a Date", Toast.LENGTH_LONG).show();
            return false;

        } else if (tv_choose_time.getText().toString().equals("Choose The Time")) {
            Toast.makeText(this, "Please Choose The Time", Toast.LENGTH_LONG).show();
            return false;
        } else {
            return true;

        }
    }

    private void sendImmediateNotification() {
        notificationManager = NotificationManagerCompat.from(this);

        channelId = String.valueOf(currentIndex); // use the id of the questionnaire as a unique id for each questionnaire's channel
        checkCurrentSdkVersion();
        //when one of the bottom methods completed , we have to register the notification
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Intent toDetails = new Intent(this, DetailsQuestionnairesActivity.class);
        toDetails.putExtra("id", currentIndex);
        toDetails.putExtra("Question", question);
        toDetails.putExtra("isActive", true);
        toDetails.putExtra("First_team", first);
        toDetails.putExtra("Second_team", second);
        toDetails.putExtra("third_team", third);
        toDetails.putExtra("date", dateStr);
        toDetails.putExtra("time", timeStr);
        toDetails.putExtra("lat", lat);
        toDetails.putExtra("lng", lng);
        TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(this);
        taskStackBuilder.addNextIntentWithParentStack(toDetails);
        PendingIntent pendingIntent = taskStackBuilder.getPendingIntent(REQUEST_CODE, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setPriority(Notification.PRIORITY_HIGH)
                .setSmallIcon(R.drawable.logo)
                .setContentTitle(question)
                .setContentText(description)
                .setVibrate(new long[]{0, 500, 700, 900})
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setSound(soundUri)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);
        PreferenceHelper helper = new PreferenceHelper(this);
        if (!helper.IS_Mute_SET())
            //if not muted , send notification
            notificationManager.notify(currentIndex, builder.build());
    }

    private void checkCurrentSdkVersion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //in case that the version that run the app is oreo or higher , then we must use Notification Channel
            CharSequence name = question;
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();
            Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationChannel channel = new NotificationChannel(channelId, name.toString().concat(String.valueOf(currentIndex)),
                    NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(description);
            channel.setShowBadge(false);
            channel.setVibrationPattern(new long[]{0, 500, 700, 900});
            channel.setSound(soundUri, audioAttributes);
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            //initiate the builder
            builder = new Notification.Builder(this, channelId);
            notificationManager.createNotificationChannel(channel);
        } else {
            //Notification channel is not necessary
            builder = new Notification.Builder(this);
        }
    }

    // فورمات ل عرض التاريخ
    public String formatToDisplayDate(long longDay) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(longDay);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        return formatter.format(calendar.getTime());
    }

    public String longToTimeString(long longTime) {
        Date date = new Date(longTime);
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm", Locale.US);
        return formatter.format(date);
    }
}
