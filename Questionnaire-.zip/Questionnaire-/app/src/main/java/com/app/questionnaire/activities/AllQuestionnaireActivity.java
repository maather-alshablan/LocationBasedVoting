package com.app.questionnaire.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.app.questionnaire.Adapter.AdapterQuestionnaire;
import com.app.questionnaire.DB.DataBaseS;
import com.app.questionnaire.DBDao.DbDao;
import com.app.questionnaire.Modle.Questionnaire;
import com.app.questionnaire.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

public class AllQuestionnaireActivity extends AppCompatActivity implements AdapterQuestionnaire.OnQuestionnaireClick {
    private static double lat, lng;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationRequest locationRequest;
    private Location location;
    private RecyclerView questionnairesRecycler;
    private AdapterQuestionnaire adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_questionnaire);

        //set back arrow event handler
        ImageView backArrow = findViewById(R.id.image_back);
        backArrow.setOnClickListener(v -> onBackPressed());

        questionnairesRecycler = findViewById(R.id.rv_questionnaires);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        if (location == null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(currentLoc -> {
                if (currentLoc != null) {
                    location = currentLoc;
                    loadAllQuestionnaires();
                } else {
                    Toast.makeText(this, "Oops , make sure the GPS is on!", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            loadAllQuestionnaires();
        }

    }

    private void loadAllQuestionnaires() {
        lat = location.getLatitude();
        lng = location.getLongitude();

        DbDao dao = DataBaseS.getInstance(this).getDao();
        dao.getAllQuestionnaire(lat, lng, true).observe(this, questionnaires -> {
            //observe the dao response , then we fill our adapter with that data
            if (questionnaires != null) {
                adapter = new AdapterQuestionnaire(this, questionnaires);
                adapter.setOnQuestionnaireClick(this);
                questionnairesRecycler.setAdapter(adapter);
            } else {
                // if it failed , then we tell user to wait for location to be fetched
                Toast.makeText(this, "There are no questionnaires in this location !", Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    public void onQuestionnaireClicked(Questionnaire questionnaire) {
        Intent i = new Intent(this, DetailsQuestionnairesActivity.class);
        i.putExtra("id", questionnaire.getId());
        i.putExtra("Question", questionnaire.getQuestion());
        i.putExtra("First_team", questionnaire.getFirst_team());
        i.putExtra("Second_team", questionnaire.getSecond_team());
        i.putExtra("third_team", questionnaire.getThird_team());
        i.putExtra("date", questionnaire.getDate());
        i.putExtra("time", questionnaire.getTime());
        i.putExtra("isActive", questionnaire.isActive());
        i.putExtra("lat", questionnaire.getLat());
        i.putExtra("lng", questionnaire.getLng());
        startActivity(i);
    }
}
