package com.app.questionnaire.BroadCast;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.TaskStackBuilder;

import com.app.questionnaire.DB.DataBaseS;
import com.app.questionnaire.DBDao.DbDao;
import com.app.questionnaire.Modle.Questionnaire;
import com.app.questionnaire.activities.DetailsQuestionnairesActivity;
import com.app.questionnaire.Helper.PreferenceHelper;
import com.app.questionnaire.R;
import com.app.questionnaire.async.AsyncTasks;

public class NotificationReceiver extends BroadcastReceiver {

    private static final int REQUEST_CODE = 200;
    private DbDao dao;
    private int questionnaireId =-1;
    private String title;
    private Notification.Builder builder;
    private NotificationManagerCompat notificationManager;
    private String channelId;

    @Override
    public void onReceive(Context context, Intent intent) {
        DataBaseS database = DataBaseS.getInstance(context);
        dao = database.getDao();
        Bundle bundle = intent.getExtras();
        questionnaireId = bundle.getInt("id");
        title = bundle.getString("title");
        boolean isActive = bundle.getBoolean("isActive");
        String firstOption = bundle.getString("First_team");
        String secondOption = bundle.getString("Second_team");
        String thirdOption = bundle.getString("third_option");
        String date = bundle.getString("date");
        String time = bundle.getString("time");
        double lat = bundle.getDouble("lat");
        double lng = bundle.getDouble("lng");

        channelId = String.valueOf(questionnaireId); // use the id of the questionnaire as a unique id for each questionnaire's channel
        checkCurrentSdkVersion(context);
        //when one of the bottom methods completed , we have to register the notification
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Intent toDetails = new Intent(context,DetailsQuestionnairesActivity.class);
        toDetails.putExtra("id",questionnaireId);
        toDetails.putExtra("Question",title);
        toDetails.putExtra("isActive",!isActive);
        toDetails.putExtra("First_team",firstOption);
        toDetails.putExtra("Second_team",secondOption);
        toDetails.putExtra("third_team",thirdOption);
        toDetails.putExtra("date","Finished on "+date );
        toDetails.putExtra("time", time );
        toDetails.putExtra("lat", lat);
        toDetails.putExtra("lng", lng);
        TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(context);
        taskStackBuilder.addNextIntentWithParentStack(toDetails);
        PendingIntent pendingIntent = taskStackBuilder.getPendingIntent(REQUEST_CODE, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setPriority(Notification.PRIORITY_HIGH)
                .setSmallIcon(R.drawable.logo)
                .setContentTitle(title)
                .setContentText("Number of voting results : " +dao.getAllVote(questionnaireId))
                .setVibrate(new long[]{0, 500, 700, 900})
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setSound(soundUri)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);
        PreferenceHelper helper = new PreferenceHelper(context);
        if (!helper.IS_Mute_SET())
            //if not muted , send notification
            notificationManager.notify(questionnaireId,builder.build());
    }

    private void checkCurrentSdkVersion(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //in case that the version that run the app is oreo or higher , then we must use Notification Channel
            CharSequence name = title;
            String description = "Number of voting results : " +dao.getAllVote(questionnaireId);
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();
            Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationChannel channel = new NotificationChannel(channelId, name.toString().concat(String.valueOf(questionnaireId)),
                    NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(description);
            channel.setShowBadge(false);
            channel.setVibrationPattern(new long[]{0, 500, 700, 900});
            channel.setSound(soundUri, audioAttributes);
            channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
            //initiate the builder
            builder = new Notification.Builder(context,channelId);
            notificationManager = NotificationManagerCompat.from(context);
            notificationManager.createNotificationChannel(channel);
        }
        else{
            //Notification channel is not necessary
            showBasicNotification(context);
        }
    }

    public void showBasicNotification(Context context) {
        //initiate the builder
        builder = new Notification.Builder(context );
        notificationManager = NotificationManagerCompat.from(context);

    }

}