package com.app.questionnaire.Modle;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// جدول اليوزر
@Entity(tableName = "users")
public class User {

    public User() {
    }

    public User(String username, String mobilenumber, String password) {
        this.username = username;
        this.mobilenumber = mobilenumber;
        this.Password = password;
    }

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String username;
    private String mobilenumber;
    private String Password;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMobilenumber() {
        return mobilenumber;
    }

    public void setMobilenumber(String mobilenumber) {
        this.mobilenumber = mobilenumber;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}
