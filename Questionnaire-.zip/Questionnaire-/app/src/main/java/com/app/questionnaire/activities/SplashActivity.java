package com.app.questionnaire.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.app.questionnaire.Helper.PreferenceHelper;
import com.app.questionnaire.Modle.Colleges;
import com.app.questionnaire.R;
import com.app.questionnaire.async.AsyncTasks;

public class SplashActivity extends AppCompatActivity{
    public static final String TAG = "SplashScreen";
    private PreferenceHelper preferences;
    private static int SPLASH_TIME_OUT = 2000;
    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 3333;
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 5445;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        preferences = new PreferenceHelper(this);

        new Handler().postDelayed(this::getLocationPermission, SPLASH_TIME_OUT);
    }

    // هذه الدالة تستخدم لاخد برمجن للتطبيق ل موقعي

    private void getLocationPermission() {
        if (isLocationEnabled(SplashActivity.this)) {

            if (ContextCompat.checkSelfPermission(SplashActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(SplashActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            } else {
                checkLogin();
            }

        } else {
            showSettingAlert();

        }
    }


    // هذه الدالة تستسخدم لفحص اذا ال gps او ال برمشن شغال او لا

    public static boolean isLocationEnabled(Context context) {
        int locationMode = 0;
        String locationProviders;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                locationMode = Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE);

            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
                return false;
            }

            return locationMode != Settings.Secure.LOCATION_MODE_OFF;

        } else {
            locationProviders = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
            return !TextUtils.isEmpty(locationProviders);
        }


    }


    // ديلوق ل تفعيل ال gps اذا مش شغال اذا شغال بيروح ع الواجهة الي بعدها بدو يعمل الغاء ما بيتطيع يدخل على ال app

    public void showSettingAlert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(SplashActivity.this);
        alertDialog.setTitle("GPS setting!");
        alertDialog.setMessage("GPS is not enabled, Do you want to go to settings menu? ");
        alertDialog.setPositiveButton("Setting", (dialog, which) -> {
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivityForResult(intent, MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        });

        alertDialog.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.cancel();
            finish();
        });

        alertDialog.setOnCancelListener(dialog -> {
            // if from activity
            ActivityCompat.finishAffinity(SplashActivity.this);
        });

        alertDialog.show();
    }


    //  هذه الدالة تستخدم لاخد برمجن للتطبيق ل موقعي اذا عمل الغاء لما يفوت ع التطبيق يستدعي البرمشن كمان مرة

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.e("requestCode", requestCode + "");
        if (requestCode == MY_PERMISSIONS_REQUEST_LOCATION ) {
            if (isLocationEnabled(SplashActivity.this)) {
                Log.e(TAG, "onRequestPermissionsResult: some error happened");
                checkLogin();
            } else {
                showSettingAlert();

            }

        }

    }

    // يتم فحص اذا في قيمة موجودة مخزنة عندي انا بحزنها عند تسجيل الدخول اذا في قيمة موجودة بيدخل على الرئيسية ما في قيمة موجودة بيروح على تسجيل الدخول

    private void checkLogin() {
        if (! preferences.isAppHasRunBefore()){
            //if its the first time the app run , then init the colleges
            AsyncTasks asyncTasks = new AsyncTasks(getApplication());
            asyncTasks.addCollege(new Colleges("College of Computer and Information Sciences", 24.7234203, 46.6347686));
            asyncTasks.addCollege(new Colleges("College of Nursing", 24.7233349, 46.6353643));
            asyncTasks.addCollege(new Colleges("College of Medicine", 24.724123, 46.6361692));
            asyncTasks.addCollege(new Colleges("College of Applied Medical Sciences, female students", 24.7249368, 46.6367118));
            asyncTasks.addCollege(new Colleges("College of Dentistry - GUC", 24.7258659, 46.6362024));
            asyncTasks.addCollege(new Colleges("College of Pharmacy", 24.726621, 46.6365946));
            asyncTasks.addCollege(new Colleges("College of Science", 24.7247584, 46.634904));
            asyncTasks.addCollege(new Colleges("Foyer and Central Plaza", 24.7280087, 46.634743));
            asyncTasks.addCollege(new Colleges("KSU Gym", 24.7264948, 46.6326347));
            asyncTasks.addCollege(new Colleges("College of Business Administration", 24.7294451, 46.6330036));
            asyncTasks.addCollege(new Colleges("KSU - College of Education - Girls", 24.7294752, 46.6313801));
            asyncTasks.addCollege(new Colleges("KSU - College of Art - Girls", 24.728063, 46.6313714));
            asyncTasks.addCollege(new Colleges("College of Law and Political Sciences", 24.7294719, 46.6301769));
            asyncTasks.addCollege(new Colleges("College of Languages and Translation", 24.7281148, 46.6328988));
            preferences.setAppHasRunBefore(true);
        }

        if (preferences.getUserId()!=-1) {
            startActivity(new Intent(this, MainActivity.class));
        } else {
            Intent i = new Intent(this, SignInActivity.class);
            startActivity(i);
        }
        finish();

    }


    //الدالة تسخدم لاخد برمشن ال gps  لاخد الموثع الخاص بي

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION) {
            if (ContextCompat.checkSelfPermission(SplashActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(SplashActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            } else {
                checkLogin();
            }
        }
    }
}
