package com.app.questionnaire.interfaces;

import android.view.View;

public interface OnItemClickListener {
    void onClick(Object parent, View view, int position);
}
