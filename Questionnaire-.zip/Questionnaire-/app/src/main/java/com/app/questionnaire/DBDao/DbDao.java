package com.app.questionnaire.DBDao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.app.questionnaire.Modle.Colleges;
import com.app.questionnaire.Modle.Questionnaire;
import com.app.questionnaire.Modle.User;
import com.app.questionnaire.Modle.Vote;

import java.util.List;

@Dao
public interface DbDao {

    // اضافة كلية جديدة في الداتا بيس
    @Insert(entity = Colleges.class, onConflict = OnConflictStrategy.REPLACE)
    long addNewColleges(Colleges colleges);

    // جملة استعلام ل عرض الكليات من الداتا بيس
    @Query("SELECT DISTINCT * FROM colleges")
    List<Colleges> getAllColleges();

    // جملة استعلام ل حذف كلية من الداتا بيس
    @Query("delete from colleges")
    void deleteAllColleges();

    // اضافة استبيان جديد في الداتا بيس
    @Insert()
    long addNewQuestionnaire(Questionnaire questionnaire);

    // تعديل استبيان  من الداتا بيس
    @Update()
    void updateQuestionnaire(Questionnaire questionnaire);

    // جملة استعلام ل عرض الاستبانات من الداتا بيس
    @Query("SELECT DISTINCT * FROM questionnaire WHERE lat = :lat  AND lng =:lng And isActive=:isActive")
    LiveData<List<Questionnaire>> getAllQuestionnaire(double lat , double lng, boolean isActive);

    // اضافة يوزر جديد في الداتا بيس
    @Insert()
    long addNewUser(User user);

    // جملة استعلام عشان افحص اذا اليوزر موجود او لا
    @Query("SELECT DISTINCT id FROM users WHERE username = :username AND Password =:Password")
    int getUser(String username, String Password);

    // اضافة تصويت جديدة في الداتا بيس
    @Insert(entity = Vote.class, onConflict = OnConflictStrategy.REPLACE)
    long addNewVote(Vote vote);

    // جملة استعلام ل نتائج التصويت من الداتا بيس
    @Query("SELECT count(*) FROM vote where questionnaireId =:questionnaireId ")
    int getAllVote(int questionnaireId);

    // جملة استعلام عشان افحص اذا اليوزر موجود او لا
    @Query("SELECT DISTINCT * FROM vote WHERE questionnaireId = :questionnaireId AND userId = :userId")
    LiveData<Vote> getUserVote(int questionnaireId , int userId);
}
