package com.app.questionnaire.async;

import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;

import com.app.questionnaire.DB.DataBaseS;
import com.app.questionnaire.DBDao.DbDao;
import com.app.questionnaire.Modle.Colleges;
import com.app.questionnaire.Modle.Questionnaire;
import com.app.questionnaire.Modle.User;
import com.app.questionnaire.Modle.Vote;

public class AsyncTasks {
    private DbDao dao;

    public AsyncTasks(Context context){
        dao = DataBaseS.getInstance(context).getDao();
    }

    public void deleteColleges(){
        new DeleteCollegesAsync(dao).execute();
    }
    public static class DeleteCollegesAsync extends AsyncTask<Void , Void , Void> {
        private final DbDao dao;
        public DeleteCollegesAsync(DbDao dao){
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            dao.deleteAllColleges();
            return null;
        }
    }

    public void updateQuestionnaire(Questionnaire questionnaire){
        new UpdateQuestionnaireAsync(dao).execute(questionnaire);
    }
    public static class UpdateQuestionnaireAsync extends AsyncTask<Questionnaire, Void , Void> {
        private final DbDao dao;
        public UpdateQuestionnaireAsync(DbDao dao){
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(Questionnaire... questionnaires) {
            dao.updateQuestionnaire(questionnaires[0]);
            return null;
        }
    }

    public void addCollege(Colleges college){
        new AddCollegeAsync(dao).execute(college);
    }
    public static class AddCollegeAsync extends AsyncTask<Colleges , Void , Void> {
        private final DbDao dao;
        public AddCollegeAsync(DbDao dao){
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(Colleges... colleges) {
            dao.addNewColleges(colleges[0]);
            return null;
        }
    }

    public void addUser(User user){
        new AddUserAsync(dao).execute(user);
    }
    public static class AddUserAsync extends AsyncTask<User , Void , Void> {
        private final DbDao dao;
        public AddUserAsync(DbDao dao){
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(User... users) {
            dao.addNewUser(users[0]);
            return null;
        }
    }

     public void addQuestionnaire(Questionnaire questionnaire){
        new AddQuestionnaireAsync(dao).execute(questionnaire);
     }
     public static class AddQuestionnaireAsync extends AsyncTask<Questionnaire , Void , Void> {
        private final DbDao dao;
        public AddQuestionnaireAsync(DbDao dao){
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(Questionnaire... questionnaires) {
            dao.addNewQuestionnaire(questionnaires[0]);
            return null;
        }
    }

    public void addVote(Vote vote){
        new AddVoteAsync(dao).execute(vote);
    }
    public static class AddVoteAsync extends AsyncTask<Vote , Void , Void> {
        private final DbDao dao;
        public AddVoteAsync(DbDao dao){
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(Vote... votes) {
            dao.addNewVote(votes[0]);
            return null;
        }
    }
}
