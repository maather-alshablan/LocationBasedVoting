package com.app.questionnaire.Modle;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// جدول التصويت
@Entity(tableName = "vote")
public class Vote {

    @PrimaryKey(autoGenerate = true) private int id;
    private int questionnaireId ;
    private int userId;
    private int option; //indicate what is voted option , 1 for the first option, 2 for the second option , 0 if nothing selected

    public Vote(int questionnaireId, int userId, int option) {
        this.questionnaireId = questionnaireId;
        this.userId = userId;
        this.option = option;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuestionnaireId() {
        return questionnaireId;
    }

    public void setQuestionnaireId(int questionnaireId) {
        this.questionnaireId = questionnaireId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getOption() {
        return option;
    }

    public void setOption(int option) {
        this.option = option;
    }
}
