package com.app.questionnaire.Modle;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// جدول الاستبيان
@Entity(tableName = "questionnaire")
public class Questionnaire {

    @PrimaryKey private int id;
    private String question ;
    private String first_team ;
    private String second_team ;
    private String third_team ;
    private double lat ;
    private double lng ;
    private String date ;
    private String time ;
    private boolean isActive;

    public Questionnaire(int id, String question, String first_team, String second_team, String third_team, double lat, double lng, String date, String time, boolean isActive) {
        this.id = id;
        this.question = question;
        this.first_team = first_team;
        this.second_team = second_team;
        this.third_team = third_team;
        this.lat = lat;
        this.lng = lng;
        this.date = date;
        this.time = time;
        this.isActive = isActive;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getFirst_team() {
        return first_team;
    }

    public void setFirst_team(String first_team) {
        this.first_team = first_team;
    }

    public String getSecond_team() {
        return second_team;
    }

    public void setSecond_team(String second_team) {
        this.second_team = second_team;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public String getThird_team() {
        return third_team;
    }

    public void setThird_team(String third_team) {
        this.third_team = third_team;
    }
}
