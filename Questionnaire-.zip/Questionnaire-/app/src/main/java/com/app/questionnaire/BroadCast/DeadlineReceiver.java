package com.app.questionnaire.BroadCast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.app.questionnaire.DB.DataBaseS;
import com.app.questionnaire.DBDao.DbDao;
import com.app.questionnaire.Modle.Questionnaire;
import com.app.questionnaire.async.AsyncTasks;

public class DeadlineReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        int questionnaireId = bundle.getInt("id");
        String title = bundle.getString("title");
        String firstOption = bundle.getString("First_team");
        String secondOption = bundle.getString("Second_team");
        String thirdOption = bundle.getString("third_team");
        String date = bundle.getString("date");
        String time = bundle.getString("time");
        double lat = bundle.getDouble("lat");
        double lng = bundle.getDouble("lng");

        //now we have to update the questionnaire as not active so that it does not appear in the list again
        AsyncTasks asyncTasks = new AsyncTasks(context);
        Questionnaire questionnaire = new Questionnaire(questionnaireId, title, firstOption, secondOption,thirdOption, lat, lng, date, time,false);
        asyncTasks.updateQuestionnaire(questionnaire);
    }
}