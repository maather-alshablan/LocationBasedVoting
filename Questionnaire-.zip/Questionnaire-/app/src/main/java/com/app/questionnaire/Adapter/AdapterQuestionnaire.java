package com.app.questionnaire.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.questionnaire.Modle.Questionnaire;
import com.app.questionnaire.R;
import java.util.List;

public class AdapterQuestionnaire extends RecyclerView.Adapter<AdapterQuestionnaire.ViewHolder> {

    Activity context;
    List<Questionnaire> list;
    private OnQuestionnaireClick onQuestionnaireClick;

    public void setOnQuestionnaireClick(OnQuestionnaireClick onQuestionnaireClick) {
        this.onQuestionnaireClick = onQuestionnaireClick;
    }

    public interface OnQuestionnaireClick{
        void onQuestionnaireClicked(Questionnaire questionnaire);
    }

    public AdapterQuestionnaire(Activity context, List<Questionnaire> list) {
        this.context = context;
        this.list = list;

    }

    // تعريف اي item اعطيتو لل RecyclerView
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_questionnaire, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int p) {
        // عرض القيم الموجودة ف ال object
        Questionnaire data = list.get(p);
        holder.tv_questionnaire.setText(data.getQuestion());


        holder.itemView.setOnClickListener(view -> {
            onQuestionnaireClick.onQuestionnaireClicked(list.get(p));
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        // اقدر اوصل للعناصر و اتحكم فيها
        TextView tv_questionnaire;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_questionnaire = itemView.findViewById(R.id.tv_questionnaire);
        }
    }
}