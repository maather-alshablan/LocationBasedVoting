package com.app.questionnaire.activities;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.app.questionnaire.BroadCast.NotificationReceiver;
import com.app.questionnaire.DB.DataBaseS;
import com.app.questionnaire.DBDao.DbDao;
import com.app.questionnaire.Helper.PreferenceHelper;
import com.app.questionnaire.Modle.Vote;
import com.app.questionnaire.R;
import com.app.questionnaire.async.AsyncTasks;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static com.app.questionnaire.activities.SignInActivity.staticUserId;

public class DetailsQuestionnairesActivity extends AppCompatActivity implements View.OnClickListener {

    public static final int REQUEST_CODE = 48589;
    private Button voteBtn;
    private RadioButton rb_first, rb_second,rb_third;

    private DbDao dao;

    private int questionnaireId;
    private int userId;

    private int selectedOption = 0;
    private Bundle data;

    private long notificationDelay = 24 * 60 * 60 * 1000 ; // notification will be after 24 hour

    private AsyncTasks asyncTasks;
    private String question;
    private String date;
    private String time;
    private boolean isActive;
    private double lat ;
    private double lng ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_questionnaires);

        dao = DataBaseS.getInstance(this).getDao();
        asyncTasks = new AsyncTasks(getApplication());
        //getting data sent to this activity
        data = getIntent().getExtras();
        questionnaireId = data.getInt("id", -1);
        findView();

    }

    private void findView() {

        PreferenceHelper preferenceHelper = new PreferenceHelper(this);
        userId = preferenceHelper.getUserId();
        if (userId == -1) {
            // if user not check rememberMe checkbox when signing in , then we will use this static variable
            userId = staticUserId;
        }

        question = data.getString("Question");
        String first_team = data.getString("First_team");
        String second_team = data.getString("Second_team");
        String third_team = data.getString("third_team");
        date = data.getString("date");
        time = data.getString("time");
        isActive = data.getBoolean("isActive");
        lat = data.getDouble("lat");
        lng = data.getDouble("lng");

        ImageView image_back = findViewById(R.id.image_back);
        TextView tv_question = findViewById(R.id.tv_question);
        TextView date_tv = findViewById(R.id.date);
        TextView time_tv = findViewById(R.id.time);
        rb_first = findViewById(R.id.rb_first);
        rb_second = findViewById(R.id.rb_second);
        rb_third = findViewById(R.id.rb_third);
        voteBtn = findViewById(R.id.btn_vote);

        image_back.setOnClickListener(this);
        //set vote button click event handler
        voteBtn.setOnClickListener(v -> {
            if (selectedOption != 0) {
                asyncTasks.addVote(new Vote(questionnaireId, userId, selectedOption));
                if(!preferenceHelper.IS_Mute_SET()){
                    //if not muted , then send notifications
                    try {
                        setupNotification();
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
            } else {
                Toast.makeText(this, "Make a select first ...", Toast.LENGTH_SHORT).show();
            }
        });

        //check if its finished
        if (!isActive){
            //if its not active , hide vote button
            voteBtn.setVisibility(View.GONE);
        }
        //get the radio group
        RadioGroup teamsRadioGroup = findViewById(R.id.radio_group);

        //initiate the view with pre-selected option if exist
        dao.getUserVote(questionnaireId, userId).observe(this, vote -> {
            TextView votedMsg = findViewById(R.id.et_voted);
            if (vote != null) {
                //if there exist a vote
                int votedOption = vote.getOption();
                votedMsg.setVisibility(View.VISIBLE);
                voteBtn.setEnabled(false);
                voteBtn.setAlpha(0.3f);
                switch (votedOption) {
                    case 1: {
                        // the user has voted for team 1
                        rb_first.setChecked(true);
                        rb_second.setEnabled(false);
                        rb_third.setEnabled(false);
                        break;
                    }
                    case 2: {
                        // the user has voted for team 2
                        rb_first.setEnabled(false);
                        rb_second.setChecked(true);
                        rb_third.setEnabled(false);
                        break;
                    }
                    case 3: {
                        // the user has voted for team 3
                        rb_first.setEnabled(false);
                        rb_second.setEnabled(false);
                        rb_third.setChecked(true);
                        break;
                    }
                }
            } else {
                votedMsg.setVisibility(View.GONE);
                //set vote listener , will register the notification to be sent to the user after 24 hour of its deadline
                teamsRadioGroup.setOnCheckedChangeListener((group, checkedBtn) -> {
                    if (checkedBtn == R.id.rb_first) {
                        selectedOption = 1;
                    } else if (checkedBtn == R.id.rb_second) {
                        selectedOption = 2;
                    }
                    else if (checkedBtn == R.id.rb_third) {
                        selectedOption = 3;
                    }

                });
            }
        });

        // عرض بيانات الاستبيان
        date_tv.setText(date);
        time_tv.setText(time);
        tv_question.setText(question);
        rb_first.setText(first_team);
        rb_second.setText(second_team);
        rb_third.setText(third_team);


    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.image_back) {
            onBackPressed();
        }
    }

    private void setupNotification() throws ParseException {
        //setting up our notification
        Intent receiverIntent = new Intent(this, NotificationReceiver.class);
        receiverIntent.putExtra("id",questionnaireId);
        receiverIntent.putExtra("title",question);
        receiverIntent.putExtra("date",date);
        receiverIntent.putExtra("time",time);
        receiverIntent.putExtra("isActive",true);
        receiverIntent.putExtra("First_team",rb_first.getText().toString());
        receiverIntent.putExtra("Second_team",rb_second.getText().toString());
        receiverIntent.putExtra("third_team",rb_third.getText().toString());
        receiverIntent.putExtra("lat",lat);
        receiverIntent.putExtra("lng",lng);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this,questionnaireId,receiverIntent,0);
        //building calendar object that we gonna use with pending intent will be sent to receiver
        Calendar calendar = Calendar.getInstance();
        Date actualDeadline = new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date);
        long delayedDate = actualDeadline.getTime() + notificationDelay;
        Date dayObj = new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(formatToDisplayDate(delayedDate));
        Date timeObj = new SimpleDateFormat("HH:mm",Locale.US).parse(time);
        calendar.setTime(timeObj);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        calendar.setTime(dayObj);
        calendar.set(Calendar.HOUR_OF_DAY,hour);
        calendar.set(Calendar.MINUTE,min);
        calendar.set(Calendar.SECOND,0);
        calendar.set(Calendar.MILLISECOND,0);

        Toast.makeText(this,"You will get the results on :" + calendar.getTime().toLocaleString(), Toast.LENGTH_LONG).show();
        AlarmManager alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),pendingIntent);
    }

    // فورمات ل عرض التاريخ
    public String formatToDisplayDate(long longDay){
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(longDay);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        return formatter.format(calendar.getTime());
    }

}
