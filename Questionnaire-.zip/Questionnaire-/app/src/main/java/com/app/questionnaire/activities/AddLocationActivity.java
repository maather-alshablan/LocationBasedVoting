package com.app.questionnaire.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.app.questionnaire.Modle.Colleges;
import com.app.questionnaire.R;
import com.app.questionnaire.async.AsyncTasks;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class AddLocationActivity extends AppCompatActivity {

    private FusedLocationProviderClient fusedLocationProviderClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_location);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        //set back arrow event handler
        ImageView backArrow = findViewById(R.id.image_back);
        backArrow.setOnClickListener(v-> onBackPressed());

        EditText nameEt = ((EditText) findViewById(R.id.loc_name));
        EditText latEt = ((EditText) findViewById(R.id.lat_et));
        EditText lngEt = ((EditText) findViewById(R.id.lng_et));
        ImageView myLocation = findViewById(R.id.get_my_location);
        myLocation.setOnClickListener(v->{
            //getting location when user click on get my location button
            fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // this permission's check is necessary for fused location to be used
                return;
            }
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(loc -> {
                if(loc != null){
                    latEt.setText(String.valueOf(loc.getLatitude()));
                    lngEt.setText(String.valueOf(loc.getLongitude()));
                    Toast.makeText(this, "Got your location successfully !", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(this, "Oops , make sure the GPS is on!", Toast.LENGTH_SHORT).show();
                }
            });
        });


        Button addLoc = findViewById(R.id.btn_add);
        addLoc.setOnClickListener(v->{

            String name = nameEt.getText().toString();
            if (!name.isEmpty() && !latEt.getText().toString().isEmpty() && !lngEt.getText().toString().isEmpty()){
                double lat = Double.parseDouble(latEt.getText().toString());
                double lng = Double.parseDouble(lngEt.getText().toString());
                addLocation(name,lat,lng);
            }
        });
    }

    private void addLocation(String name, double lat, double lng) {
        AsyncTasks asyncTasks = new AsyncTasks(getApplication());
        asyncTasks.addCollege(new Colleges(name,lat,lng));
        //when added , return to home
        finish();
    }
}