package com.app.questionnaire.Helper;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceHelper {

    private  SharedPreferences sharedPreferences;
    private  final String IS_Mute_SET = "is_mute_set";
    private  final String LAST_ID = "Last_id";
    private String USER_ID = "user_id_";
    private String USER_NAME = "username_";
    private String USER_PASSWORD = "password_";
    private String RUN_BEFORE = "Run_Before";


    public PreferenceHelper(Context context) {
        sharedPreferences=context.getSharedPreferences("pref",Context.MODE_PRIVATE);
    }

    public  int getLastId() {
        //when its the first time this method run , it will return 0
        return sharedPreferences.getInt(LAST_ID,0);
    }

    public  void setLastId(int id){
        sharedPreferences.edit().putInt(LAST_ID,id).apply();
    }

    public void setIsMute(boolean isMuted){
        sharedPreferences.edit().putBoolean(IS_Mute_SET,isMuted).apply();
    }

    public boolean IS_Mute_SET(){
        return sharedPreferences.getBoolean(IS_Mute_SET,false);
    }

    public int getUserId() {
        return sharedPreferences.getInt(USER_ID,-1);
    }

    public void setUserId(int userId) {
        sharedPreferences.edit().putInt(USER_ID,userId).apply();
    }

    public String getUsername() {
        return sharedPreferences.getString(USER_NAME,"");
    }

    public void setUsername(String username) {
        sharedPreferences.edit().putString(USER_NAME,username).apply();

    }

    public boolean isAppHasRunBefore() {
        return sharedPreferences.getBoolean(RUN_BEFORE,false);
    }

    public void setAppHasRunBefore(boolean appHasRunBefore) {
        sharedPreferences.edit().putBoolean(RUN_BEFORE,appHasRunBefore).apply();
    }

    public String getPassword() {
        return sharedPreferences.getString(USER_PASSWORD,"");
    }

    public void setPassword(String password) {
        sharedPreferences.edit().putString(USER_PASSWORD,password).apply();

    }
}
